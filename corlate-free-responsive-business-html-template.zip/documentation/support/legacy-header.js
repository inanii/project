/*!

Support JS for legacy browsers.
Includes:

  HTML5 Shiv
    @afarkas @jdalton @jon_neal @rem
    MIT/GPL2 Licensed
    https://github.com/aFarkas/html5shiv

  matchMedia() polyfill
    (c) 2012: Scott Jehl, Paul Irish, Nicholas Zakas. Dual MIT/BSD license

  Respond.js
    min/max-width media query polyfill
    (c) Scott Jehl. MIT/GPLv2 Lic.
    http://j.mp/respondjs

*/
